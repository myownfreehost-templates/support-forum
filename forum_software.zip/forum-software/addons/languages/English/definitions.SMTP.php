<?php
// Copyright 2013 Toby Zerner, Simon Zerner
// This file is part of esoTalk. Please see the included license file for usage information.

// English Definitions for the SMTP plugin.

$definitions["Server"] = "Server";
$definitions["Port"] = "Port";
$definitions["Authentication"] = "Authentication";
$definitions["Normal"] = "Normal";
$definitions["TLS"] = "TLS";
$definitions["SSL"] = "SSL";