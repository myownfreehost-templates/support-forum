<?php
// Copyright 2011 Toby Zerner, Simon Zerner
// This file is part of esoTalk. Please see the included license file for usage information.

// English Definitions for the Debug plugin.

$definitions["MySQL queries"] = "MySQL queries";
$definitions["Page loaded in %s seconds"] = "Page loaded in %s seconds";
$definitions["POST + GET + FILES information"] = "POST + GET + FILES information";
$definitions["SESSION + COOKIE information"] = "SESSION + COOKIE information";