<?php
// Copyright 2011 Toby Zerner, Simon Zerner
// This file is part of esoTalk. Please see the included license file for usage information.

if (!defined("IN_ESOTALK")) exit;

/**
 * Displays the admin dashboard, including forum statistics and an esoTalk news feed. Also initiates a check
 * for updates to the esoTalk software.
 *
 * @package esoTalk
 */
?>
<script>
$(function() {
	ETAdminDashboard.init();
});
</script>



<div class='section'>
<div class='info'>
<h3><?php echo T("Forum Statistics"); ?></h3>
<ul class='form'>
<?php foreach ($data["statistics"] as $k => $v): ?><li><label><?php echo $k; ?></label> <?php echo $v; ?></li><?php endforeach; ?>
</ul>
</div>
</div>


</div>
