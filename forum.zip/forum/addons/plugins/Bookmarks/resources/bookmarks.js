$(function() {

	ETConversation.toggleBookmarked = function() {

		$.ETAjax({
			url: "conversation/bookmark.ajax/" + ETConversation.id,
			success: function(data) {
				$("#conversationHeader .labels").html(data.labels);
			}
		});
	};

	$("#control-bookmark").click(function(e) {
		e.preventDefault();
		ETConversation.toggleBookmarked();
	});

});	
