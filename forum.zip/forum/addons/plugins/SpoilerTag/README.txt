## Translation
Create `definitions.SpoilerTag.php` in your language pack with the following definition:

$definitions["SpoilerBBCode"] = "Spoiler";
