<?php
if (!defined('IN_ESOTALK')) exit;
$form = $data['form'];
?>
<div class="captcha">
  <small>1+1=?</small>
  <?php echo $form->input('captcha', 'text', array('placeholder' => '', 'value' => '', 'tabindex' => $data['tabindex'] )) ?>
</div>
