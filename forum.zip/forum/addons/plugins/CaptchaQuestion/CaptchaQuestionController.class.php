<?php

if (!defined("IN_ESOTALK")) exit;

class CaptchaQuestionController extends ETController {
}
