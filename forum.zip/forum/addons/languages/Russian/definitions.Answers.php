<?PHP
$definitions["Answer"] = "Ответ";
$definitions["Answered"] = "Отвечен";
$definitions["Answered by %s"] = "Отвечен %s";
$definitions["label.answered"] = "Отвечен";
$definitions["Remove answer"] = "Удалить ответ";
$definitions["See post in context"] = "Смотрите пост в контексте";
$definitions["This answers my question"] = "Это отвечает на мой вопрос";
$definitions["This answers the question"] = "Это отвечает на вопрос";