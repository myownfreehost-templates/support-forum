# EsoTalk_Russian_lang
Full Russian Lang for EsoTalk and all of the Plugins

=================================

Полный перевод ЕsoTalk и всех плагинов. То что не было переведено, находитса в самих файлах не имеющих Т(""). Нужно переводить самим. 

Enjoy!
