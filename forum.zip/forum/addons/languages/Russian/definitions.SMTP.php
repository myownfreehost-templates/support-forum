<?php

	$definitions["Server"] = "Сервер";
	$definitions["Port"] = "Порт";
	$definitions["Authentication"] = "Аутентификация";
	$definitions["Normal"] = "Нормальный";
	$definitions["TLS"] = "TLS";
	$definitions["SSL"] = "SSL";