<?php
$definitions["hidden.YouMustBeLoggedIn"] = "Вы должны авторизоваться, для возможности просмотра этого контента.";
$definitions["hidden.YouMustHavePosts"] = "Вы должны иметь $1 сообщений на форуме, для возможности просмотра этого контента.";
$definitions["hidden.YouMustBeInGroups"] = "Вы должны состоять в группе « $1 », для возможности просмотра этого контента.";
$definitions["hidden.ContentForUsers"] = "Приватный контент только для пользователя: $1.";