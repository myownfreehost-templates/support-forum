<?PHP
$definitions["email.postMember.body"] = "<p><strong>%1\$s</strong> написал в беседе: <strong>%2\$s</strong></p><hr>%3\$s<hr><p>Чтобы просмотреть новую активность, перейдите по следующей ссылке:<br>%4\$s</p>";
$definitions["email.postMember.subject"] = "Есть новый пост от %1\$s";
$definitions["Email me when there is a new post by a member I have followed"] = "Напишите мне, когда появится новый пост от участника, на которого я подписан";