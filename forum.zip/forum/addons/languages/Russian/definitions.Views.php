<?PHP
$definitions["gambit.order by views"] = "сортировать по просмотрам";
$definitions["%s view"] = "%s просмотр";
$definitions["%s views"] = "%s просмотров";