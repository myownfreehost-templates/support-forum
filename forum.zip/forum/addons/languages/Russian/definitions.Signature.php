<?PHP
$definitions["BBCode Allowed"] = "BB-код разрешен";
$definitions["Characters"] = "Симвилы";
$definitions["Enter the amount of signature characters allowed."] = "Введите допустимое количество симвилов подписи.";
$definitions["Max characters:"] = "Максимальное количество символов:";
$definitions["Signature"] = "Подпись";
