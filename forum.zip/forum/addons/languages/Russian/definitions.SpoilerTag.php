<?PHP
$definitions["SpoilerBBCode"] = "Спойлер";