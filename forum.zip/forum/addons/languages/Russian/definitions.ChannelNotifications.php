<?php
$definitions["email.postChannel.body"] = "<p><strong>%1\$s</strong> опубликовал в беседе на канале, на который вы подписаны: <strong>%2\$s</strong></p><hr>%3\$s<hr><p>Чтобы просмотреть новую активность, перейдите по следующей ссылке:<br>%4\$s</p>";
	$definitions["email.postChannel.subject"] = "[%1\$s] %2\$s";
	$definitions["Email me when someone posts in a channel I have followed"] = "Напишите мне, когда кто-то публикует сообщения на канале, на который я подписан";