<?php
$definitions["Change your avatar on %s."] = "Сменить аватарку на %s.";	
	$definitions["Default imageset"] = "Набор изображений по умолчанию";
	$definitions["Default"] = "По умолчанию";