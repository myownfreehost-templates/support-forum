<?php
$definitions["Un-shadow ban"] = "Убрать теневой бан";    
    $definitions["Shadow ban"] = "Теневой бан";    
    $definitions["This member has been shadow-banned"] = "Этот участник был заблокирован тенью"; 