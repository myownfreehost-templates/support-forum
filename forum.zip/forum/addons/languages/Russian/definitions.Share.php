<?php
$definitions["Share"] = "Поделиться";
$definitions["Share on"] = "Поделись";