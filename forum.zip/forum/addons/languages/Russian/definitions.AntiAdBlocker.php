<?PHP
$definitions["AntiAdBlocker"] = "Пожалуйста отключите свой блокиратор рекламы!";