<?PHP
$definitions["User since"] = "Год регистрации";