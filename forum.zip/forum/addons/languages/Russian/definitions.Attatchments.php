<?PHP
$definitions["Attach a file"] = "Прикрепить файл";
$definitions["Drop files to upload"] = "Перетащите файлы для загрузки";
$definitions["Embed in post"] = "Вставить в пост";
$definitions["message.attachmentNotFound"] = "По какой-то причине это вложение не может быть просмотрено. Он может не существовать, или у вас может не быть разрешения на его просмотр.";