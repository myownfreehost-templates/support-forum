<?php

	$definitions["MySQL queries"] = "Запросы MySQL";
	$definitions["Page loaded in %s seconds"] = "Страница загружалась в течение % секунд";
	$definitions["POST + GET + FILES information"] = "Информация POST + GET + FILES";
	$definitions["SESSION + COOKIE information"] = "Информация SESSION + COOKIE";