<?PHP
$definitions["About"] = "Обо мне";
$definitions["Create Field"] = "Создать поле";
$definitions["Edit Field"] = "Редактировать поле";
$definitions["Field description"] = "Описание поля";
$definitions["Field name"] = "Имя поля";
$definitions["Hide field from guests"] = "Скрыть поле от гостей";
$definitions["Input type"] = "Тип ввода";
$definitions["Location"] = "Место расположения";
$definitions["Manage Profile Fields"] = "Управление полями профиля";
$definitions["Options"] = "Опции";
$definitions["Privacy"] = "Конфиденциальность";
$definitions["Show field on posts"] = "Показать поле в сообщениях";
$definitions["Write something about yourself."] = "Напишите что-нибудь о себе.";