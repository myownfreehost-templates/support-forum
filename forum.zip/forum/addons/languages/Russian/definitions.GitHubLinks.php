<?php
$definitions["GitHub repository"] = "Репозиторий GitHub";