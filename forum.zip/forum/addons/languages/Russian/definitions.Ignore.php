<?php
$definitions["Unignore"] = "Не игнорировать";    
	$definitions["Unignore member"] = "Не игнорировать участника";	
    $definitions["Ignore member"] = "Игнорировать участника";    
	$definitions["Ignored"] = "Игнорируется";	
	$definitions["message.noIgnoredMembers"] = "Вы не проигнорировали ни одного участника. Чтобы игнорировать участника, перейдите в его профиль и выберите <strong>Управление &rarr; Игнорировать участника</strong>";