<?php
// Copyright 2014 andrewks
// 

// Russian Definitions for the CaptchaUser plugin.

$definitions["plugin.CaptchaUser.joinSheetLabel"] = "Страница 'join'";
$definitions["plugin.CaptchaUser.joinSheetDesc"] = "Использовать на странице регистрации";
$definitions["plugin.CaptchaUser.forgotSheetLabel"] = "Страница 'forgot'";
$definitions["plugin.CaptchaUser.forgotSheetDesc"] = "Использовать на странице восстановления пароля";
$definitions["plugin.CaptchaUser.captchaLabel"] = "Защита от спам-ботов";
$definitions["plugin.CaptchaUser.captchaDesc"] = "Введите код";
$definitions["plugin.CaptchaUser.message.refreshImage"] = "Обновить";
$definitions["plugin.CaptchaUser.message.wrongCode"] = "Вы ввели неверный код! Попробуйте ещё раз.";
