<?php
$definitions["Tracking ID"] = "Идентификатор отслеживания/Tracking ID";
	$definitions["message.trackingIdHelp"] = "Получите идентификатор отслеживания, зайдя в раздел <em>Администрирование</em> вашего ресурса Google Analytics и выбрав <em>Настройки ресурса</em>.";