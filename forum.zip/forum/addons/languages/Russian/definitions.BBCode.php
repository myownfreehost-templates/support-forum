<?php

	$definitions["Code"] = "Код";
	$definitions["Image"] = "Изображение";
	$definitions["Map"] = "Карта";
	$definitions["Link"] = "Ссылка";
	$definitions["Strike"] = "Зачёркнутый текст";
	$definitions["Header"] = "Заголовок";
	$definitions["Italic"] = "Наклонный текст";
	$definitions["Bold"] = "Жирный текст";