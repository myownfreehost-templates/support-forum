<?php
$definitions["Bookmark"] = "Закладка";
	$definitions["Unbookmark"] = "Снять закладку";
	$definitions["gambit.bookmarked"] = "добавлен в закладки";
	$definitions["label.bookmarked"] = "В закладках";