<?PHP
$definitions["Add a Converstation Warning"] = "Добавить предупреждение о разговоре";
$definitions["Define the rules of a Conversation"] = "Определить правила этой беседы";
$definitions["Edit Warning"] = "Изменить предупреждение";
$definitions["Remove Warning"] = "Удалить предупреждение";
$definitions["Warning"] = "ПРЕДУПРЕЖДЕНИЕ";