<?php
// Copyright 2023 merab mazmanian
// This file is part of forum software. Please see the included license file for usage information.

ET::$languageInfo["Georgian"] = array(
	"locale" => "ka_ge",
	"name" => "ქართული",
	"description" => "ქართული ენის პაკეტი.",
	"version" => ESOTALK_VERSION,
	"author" => "მერაბი მაზმანიანი",
	"authorEmail" => "forumi.eu.org@gmail.com",
	"authorURL" => "https://forumi.eu.org",
	"license" => ""
);

// Define the character set that this language uses.
$definitions["charset"] = "utf-8";
$definitions["%s view"] = "%s ნახვა";
$definitions["%s views"] = "%s ნახვები";
$definitions["gambit.order by views"] = "ნახვების მიხედვით";
$definitions["Answer"] = "პასუხი";
$definitions["Error"] = "შეცდომა";
$definitions["See post in context"] = "იხილეთ გამოხმაურება კონტექსტში";
$definitions["Remove answer"] = "პასუხის წაშლა";
$definitions["Answered by %s"] = "კითხვას უპასუხა მან %s";
$definitions["%s and %s"] = "%s და %s";
$definitions["%s others"] = "%s სხვები";
$definitions["%s likes this."] = "%s-ს მოსწონს ეს.";
$definitions["Members Who Liked This Post"] = "წევრები, რომლებსაც მოეწონათ ეს პოსტი";
$definitions["date.full"] = "%c";
$definitions["Privacy"] = "ხელმისაწვდომი";
$definitions["Unignore conversation"] = "იგნორის გაუქმება";
$definitions["%d day ago"] = "გუშინ";
$definitions["%d days ago"] = "%d დღის წინ";
$definitions["%d hidden"]  = "%d დამალული";
$definitions["%d hour ago"] = "1 საათის წინ";
$definitions["%d hours ago"] = "%d საათის წინ";
$definitions["%d minute ago"] = "1 წუთის წინ";
$definitions["%d minutes ago"] = "%d წუთის წინ";
$definitions["%d month ago"] = "1 თვის წინ";
$definitions["%d months ago"] = "%d თვის წინ";
$definitions["%d second ago"] = "1 წამის წინ";
$definitions["%d seconds ago"] = "%d წამის წინ";
$definitions["%d week ago"] = "გასულ კვირას";
$definitions["%d weeks ago"] = "%d კვირის წინ";
$definitions["%d year ago"] = "გასულ წელს";
$definitions["%d years ago"] = "%d წლის წინ";

$definitions["%s and %s"] = "%s და %s";
$definitions["%s, %s and %s"] = "%s, %s და %s";
$definitions["%s can view this conversation."] = "%s შეუძლია ამ საუბრის ნახვა.";
$definitions["%s changed %s's group to %s."] = "%s შეიცვალა %s's ჯგუფში %s.";
$definitions["%s changed your group to %s."] = "%s შეიცვალა თქვენს ჯგუფში %s.";
$definitions["%s conversation"] = "%s საუბარი";
$definitions["%s conversations"] = "%s საუბრები";
$definitions["%s has registered and is awaiting approval."] = "%s დარეგისტრირდა და ელოდება დამტკიცებას.";
$definitions["%s invited you to %s."] = "%s მოგიწვიათ %s.";
$definitions["%s joined the forum."] = "%s გაწევრიანდა ფორუმში.";
$definitions["%s mentioned you in %s."] = "%s მოგახსენეთ %s.";
$definitions["%s post"] = "%s გამოხმაურება";
$definitions["%s posted %s"] = "%s გამოქვეყნებულია %s";
$definitions["%s posted in %s."] = "%s გამოქვეყნებული %s.";
$definitions["%s posts"] = "%s გამოხმაურებები";
$definitions["%s reply"] = "%s პასუხი";
$definitions["%s replies"] = "%s პასუხები";
$definitions["%s Settings"] = "%s პარამეტრები";
$definitions["%s started the conversation %s."] = "%s დაიწყო საუბარი %s.";
$definitions["%s will be able to view this conversation."] = "%s შეძლებს ამ საუბრის ნახვას.";
$definitions["%s will be able to:"] = "%s შეძლებს:";

$definitions["A new version of esoTalk (%s) is available."] = "ახალი ვერსია ძრავის (%s) თავისუფალია.";
$definitions["a private conversation"] = "პირადი საუბარი";
$definitions["Automatically follow conversations that I reply to"] = "ავტომატურად თვალყური ადევნეთ საუბრებს, რომლებზეც მე ვპასუხობ";
$definitions["Automatically follow private conversations that I'm added to"] = "ავტომატურად თვალყური ადევნეთ პირად საუბრებს, რომლებშიც მე დამატებული ვარ";
$definitions["Access the administrator control panel."] = "ადმინისტრატორის მართვის პანელის გამოყენება.";
$definitions["Account type"] = "პროფილის ტიპი";
$definitions["Activate"] = "გააქტიურება";
$definitions["Activity"] = "აქტივობა";
$definitions["Add"] = "დამატება";
$definitions["Administration"] = "ადმინისტრირება";
$definitions["Administrator email"] = "ადმინისტრაციის ელ. ფოსტა";
$definitions["Administrator password"] = "ადმინისტრატორის პაროლი";
$definitions["Administrator username"] = "Aადმინისტრატორის მომხმარებლის სახელი";
$definitions["Advanced options"] = "დამატებითი პარამეტრები";
$definitions["All Channels"] = "ყველა განყოფილება";
$definitions["Allow members to edit their own posts:"] = "მიეცით უფლება წევრებს დაარედაქტირონ საკუთარი გამოხმაურებები:";
$definitions["Already have an account? <a href='%s' class='link-login'>Log in!</a>"] = "უკვე ხართ დარეგისტრირებული? <a href='%s' class='link-login'>ავტორიზაცია!</a>";
$definitions["Appearance"] = "გარეგნობა";
$definitions["Approve"] = "დამტკიცება";
$definitions["Automatically star conversations that I reply to"] = "ავტომატურად თვალყური ადევნეთ საუბრებს, რომლებზეც მე ვპასუხობ";
$definitions["Avatar"] = "სურათი";

$definitions["Back to channels"] = "უკან განყოფილებებში";
$definitions["Back to conversation"] = "უკან საუბარში";
$definitions["Back to member"] = "უკან მომხმარებელში";
$definitions["Back to members"] = "უკან მომხმარებლებში";
$definitions["Back to search"] = "უკან შებნაში";
$definitions["Background color"] = "ფონის ფერი";
$definitions["Background image"] = "ფონის სურათი";
$definitions["Base URL"] = "ბაზის ბმული";
$definitions["Bold"] = "მსხვილი";
$definitions["By %s"] = "მან %s";

$definitions["Can suspend/unsuspend members"] = "შეუძლია წევრების დაბლოკვა/განბლოკვა";
$definitions["Cancel"] = "გაუქმება";
$definitions["Change"] = "შეცვლა";
$definitions["Change %s's Permissions"] = "შეცვლა %s's უფლებების";
$definitions["Change avatar"] = "სურათის შეცვლა";
$definitions["Change Channel"] = "განყოფილების შეცვლა";
$definitions["Change channel"] = "განყოფილების შეცვლა";
$definitions["Change username"] = "მომხმარებლის სახელის შეცვლა";
$definitions["Change Password or Email"] = "პაროლის ან ელ. ფოსტის შეცვლა";
$definitions["Change Password"] = "პაროლის შეცვლა";
$definitions["Change password"] = "შეცვალეთ პაროლი";
$definitions["Change permissions"] = "უფლებების შეცვლა";
$definitions["Channel description"] = "აღწერილობის შეცვლა";
$definitions["Channel List"] = "განყოფილების სია";
$definitions["Channel title"] = "განყოფილების სათაური";
$definitions["Channel slug"] = "განყოფილება ბმულში";
$definitions["Channels"] = "განყოფილებები";
$definitions["Choose a Channel"] = "აირჩიეთ განყოფილება";
$definitions["Choose a secure password of at least %s characters"] = "აირჩიეთ უსაფრთხო პაროლი მინიმუმ %s სიმბოლო";
$definitions["Choose what people will see when they first visit your forum."] = "აირჩიეთ, რას ნახავენ ადამიანები, როდესაც ისინი პირველად ეწვევიან თქვენს ფორუმს.";
$definitions["Click on a member's name to remove them."] = "დააწკაპუნეთ წევრის სახელზე მათი წასაშლელად.";
$definitions["Close registration"] = "რეგისტრაციის დახურვა";
$definitions["Confirm password"] = "დაადასტურეთ პაროლი";
$definitions["Controls"] = "მართვა";
$definitions["Conversation"] = "საუბარი";
$definitions["Conversations participated in"] = "მონაწილეობდა საუბრებში";
$definitions["Conversations started"] = "დაწყებული საუბრები";
$definitions["Conversations"] = "საუბრები";
$definitions["Copy permissions from"] = "დააკოპირეთ ნებართვები";
$definitions["Create Channel"] = "განყოფილების შექმნა";
$definitions["Create Group"] = "ჯგუფის შექმნა";
$definitions["Create Member"] = "წევრის შექმნა";
$definitions["Customize how users can become members of your forum."] = "შეცვალეთ, როგორ გახდნენ მომხმარებლები თქვენი ფორუმის წევრები.";
$definitions["Customize your forum's appearance"] = "შეცვალეთ თქვენი ფორუმის გარეგნობა";

$definitions["Dashboard"] = "მაჩვენებლები";
$definitions["Default forum language"] = "ფორუმის ენა";
$definitions["<strong>Delete</strong> all conversations forever."] = "<strong>წაშლა</strong> ყველა საუბარი სამუდამოდ.";
$definitions["Delete Channel"] = "განყოფილების წაშლა";
$definitions["Delete conversation"] = "საუბრის წაშლა";
$definitions["Delete member"] = "მომხმარებლის წაშლა";
$definitions["Delete Member"] = "წევრის წაშლა";
$definitions["<strong>Delete this member's posts.</strong> All of this member's posts will be marked as deleted, but will be able to be restored manually."] = "<strong>წაშალეთ ამ წევრის პოსტები.</strong> ამ წევრის ყველა პოსტი მოინიშნება როგორც წაშლილი, მაგრამ შესაძლებელი იქნება ხელით აღდგენა.";
$definitions["Delete"] = "წაშლა";
$definitions["Deleted %s by %s"] = "წაშლილია %s მან %s";
$definitions["Deny"] = "უარყოფა";
$definitions["Disable"] = "გამორთვა";
$definitions["Discard"] = "გაუქმება";
$definitions["Don't allow other users to see when I am online"] = "არ მისცეთ უფლება სხვა მომხმარებლებს ნახონ, როცა ხაზზე ვარ";
$definitions["Don't have an account? <a href='%s' class='link-join'>Sign up!</a>"] = "არ ხართ დარეგისტრირებული? <a href='%s' class='link-join'>რეგისტრაცია!</a>";
$definitions["Don't repeat"] = "არ გაიმეორო";
$definitions["Don't require users to confirm their account"] = "არ მოითხოვოთ მომხმარებლების პროფილის დადასტურება";

$definitions["Edit Channel"] = "განყოფილების რედაქტირება";
$definitions["Edit Group"] = "ჯგუფის რედაქტირება";
$definitions["Edit member groups"] = "მომხმარებლის ჯგუფის რედაქტირება";
$definitions["Edit your profile"] = "თქვენი პროფილის რედაქტირება";
$definitions["Edit"] = "რედაქტირება";
$definitions["Edited %s by %s"] = "რედაქტირებულია %s მან %s";
$definitions["Editing permissions"] = "რედაქტირების ნებართვები";
$definitions["Email me when I'm added to a private conversation"] = "მომწერეთ ელ. ფოსტა, როცა დავამატებ პირად საუბარში";
$definitions["Email me when someone mentions me in a post"] = "მომწერეთ ელ. ფოსტა, როცა ვინმე მომიხსენიებს გამოხმაურებაში";
$definitions["Email me when someone posts in a channel I have followed"] = "მომწერეთ ელ. ფოსტა, როცა ვინმე იაქტიურებს იმ განყოფილებაში რომელიც გამოვიწერე";
$definitions["Email me when someone posts in a conversation I have followed"] = "მომწერეთ ელ. ფოსტა, როცა ვინმე იაქტიურებს იმ საუბარში რომელიც გამოვიწერე";
$definitions["Email me when there is a new post by a member I have followed"] = "მომწერეთ ელ. ფოსტა, როცა იაქტიურებს მომხმარებელი რომელიც გამოვიწერე";
$definitions["Email"] = "ელ. ფოსტა";
$definitions["Enable"] = "ჩართვა";
$definitions["Enabled"] = "ჩარტულია";
$definitions["Enter a conversation title"] = "შეიყვანეთ საუბრის სათაური";
$definitions["Error"] = "შეცდომა";
$definitions["esoTalk version"] = "ძრავის ვერსია";
$definitions["Everyone"] = "ყველა";

$definitions["Fatal Error"] = "ფატალური შეცდომა";
$definitions["Feed"] = "არხი";
$definitions["Filter by name or group..."] = "ძებნა სახელის ან ჯგუფის სახელით...";
$definitions["Find this post"] = "იპოვე ეს პოსტი";
$definitions["First posted"] = "პირველად გამოქვეყნდა";
$definitions["Follow"] = "გამოწერა";
$definitions["Follow to receive notifications"] = "გამოიწერეთ შეტყობინებების მისაღებად";
$definitions["Following"] = "გამოწერილია";
$definitions["For %s seconds"] = "ამ %s წუთში";
$definitions["Forever"] = "სამუდამოდ";
$definitions["Forgot?"] = "დაგავიწყდათ?";
$definitions["Forgot Password"] = "აღადგინე პაროლი";
$definitions["Forum"] = "ფორუმი";
$definitions["Forum header"] = "ფორუმის სათაური";
$definitions["Forum language"] = "ფორუმის ენა";
$definitions["Forum privacy"] = "კონფიდენციალურობა";
$definitions["Forum Settings"] = "პარამეტრები";
$definitions["Forum Statistics"] = "ფორუმის სტატისტიკა";
$definitions["Forum title"] = "ფორუმის სათაური";
$definitions["forumDescription"] = "%s არის ვებ-ფორუმი, სადაც განიხილება %s, და %s.";

$definitions["Give this group the 'moderate' permission on all existing channels"] = "მიეცით ამ ჯგუფს 'მოდერირების' ნებართვა ყველა არსებულ განყოფილებაში";
$definitions["Global permissions"] = "გლობალური ნებართვები";
$definitions["Go to top"] = "ასვლა ზევით";
$definitions["Group name"] = "ჯგუფის სახელი";
$definitions["group.administrator"] = "ადმინისტრატორი";
$definitions["group.administrator.plural"] = "ადმინისტრატორები";
$definitions["group.guest"] = "სტუმარი";
$definitions["group.guest.plural"] = "სტუმრები";
$definitions["group.member"] = "მომხმარებელი";
$definitions["group.member.plural"] = "მომხმარებლები";
$definitions["group.Moderator"] = "მოდერეტორი";
$definitions["group.Moderator.plural"] = "მოდერატორები";
$definitions["group.suspended"] = "ბლოკირებულები";
$definitions["Groups can be used to categorize members and give them certain privileges."] = "ჯგუფები შეიძლება გამოყენებულ იქნას წევრების კატეგორიზაციისთვის და მათთვის გარკვეული პრივილეგიების მისაცემად.";
$definitions["Groups"] = "ჯგუფები";
$definitions["Guests can view the:"] = "სტუმრებს შეუძლიათ იხილონ:";

$definitions["Header"] = "სატაური";
$definitions["Header color"] = "სათაურის ფერი";
$definitions["Heads Up!"] = "თავები მაღლა!";
$definitions["hidden"] = "დამალული";
$definitions["Hide"] = "დამალვა";
$definitions["Home page"] = "მთავარი გვერდი";
$definitions["HTML is allowed."] = "HTML ნებადართულია.";

$definitions["If you run into any other problems or just want some help with the installation, feel free to ask for assistance at the <a href='%s'>esoTalk support forum</a>."] = "თუ რაიმე სხვა პრობლემა შეგექმნათ ან უბრალოდ გჭირდებათ დახმარება ინსტალაციასთან დაკავშირებით, თავისუფლად მოითხოვეთ დახმარება <a href='%s'>ძრავის მხარდაჭერის ფორუმში</a>.";
$definitions["Ignore conversation"] = "საუბრის იგნორი";
$definitions["Install esoTalk"] = "ძრავის ინსტალაცია";
$definitions["Install My Forum"] = "ჩემი ფორუმის ინსტალაცია";
$definitions["Installed Languages"] = "დაინსტალირებული ენები";
$definitions["Installed Plugins"] = "დაინსტალირებული დანამატები";
$definitions["Installed plugins"] = "დაინსტალირებული დანამატები";
$definitions["Installed Skins"] = "დაინსტალირებული გარეგნობები";
$definitions["Installed skins"] = "დაინსტალირებული გარეგნობები";
$definitions["is %s"] = "is %s";

$definitions["Joined"] = "დარეგისტრირდა";
$definitions["just now"] = "ამჟამად";

$definitions["Keep me logged in"] = "დამტოვე სისტემაში";
$definitions["<strong>Keep this member's posts.</strong> All of this member's posts will remain intact, but will show [deleted] as the author."] = "<strong>შეინახეთ ამ წევრის გამოხმაურებები.</strong> ამ წევრის ყველა გამოხმაურება ხელუხლებელი დარჩება, მაგრამ გამოჩნდება [წაშლილი] როგორც ავტორი.";

$definitions["label.draft"] = "შენახული";
$definitions["label.locked"] = "დახურული";
$definitions["label.ignored"] = "იგნორირებული";
$definitions["label.private"] = "პირადი";
$definitions["label.sticky"] = "მიმაგრებული";
$definitions["Labels"] = "იარლიყები";
$definitions["Last active"] = "აქტიური";
$definitions["Last active %s"] = "ბოლოს აქტიური %s";
$definitions["Latest"] = "ბოლო";
$definitions["Latest News"] = "ბოლო სიახლეები";
$definitions["Loading..."] = "იტვირთება...";
$definitions["Lock"] = "დახურვა";
$definitions["Log In"] = "ავტორიზაცია";
$definitions["Log Out"] = "გასვლა";

$definitions["Make member and online list visible to:"] = "გახდეთ წევრი და ონლაინ სიაში ხილული:";
$definitions["Manage Channels"] = "განყოფილებების მართვა";
$definitions["Manage Groups"] = "ჯგუფების მართვა";
$definitions["Manage Languages"] = "ენების მართვა";
$definitions["Manage your forum's channels (categories)"] = "მართეთ თქვენი ფორუმის განყოფილებები (კატეგორიები)";
$definitions["Mark as read"] = "მონიშვნა როგორც წაკითხული";
$definitions["Mark as unread"] = "მონიშვნა როგორც წაუკითხავი";
$definitions["Mark all as read"] = "მონიშვნა ყველაფერი წაკითხულად";
$definitions["Mark listed as read"] = "მონიშვნა ჩამოთვლილი წაკითხულად";
$definitions["Maximum size of %s. %s."] = "მაქსიმალური ზომა %s. %s.";
$definitions["Member groups"] = "მომხმარებლის ჯგუფები";
$definitions["Member list"] = "მომხმარებლის სია";
$definitions["Member List"] = "წევრის სია";
$definitions["Member privacy"] = "წევრის კონფიდენციალურობა";
$definitions["Members"] = "მომხმარებლები";
$definitions["Members Allowed to View this Conversation"] = "წევრებს უფლება აქვთ ნახონ ეს საუბარი";
$definitions["Members Awaiting Approval"] = "მომხმარებლები დამტკიცების მოლოდინში";
$definitions["Members Online"] = "მომხმარებლები ხაზზე";
$definitions["Members who are part of this group can be listed by searching for the group name in the member list."] = "მომხმარებლები, რომლებიც ამ ჯგუფის წევრები არიან, შეიძლება ჩამოვთვალოთ ჯგუფის სახელის ძიებით გაწევრიანებულთა სიაში.";
$definitions["Mobile skin"] = "მობილური დიზაინი";
$definitions["Moderate"] = "მოდერირება";
$definitions["<strong>Move</strong> conversations to the following channel:"] = "<strong>გადატანა</strong> საუბრების გამოწერილ განყოფილებაში:";
$definitions["Mute conversation"] = "საუბრის ჩაჩუმება";
$definitions["MySQL database"] = "MySQL მონაცემთა ბაზა";
$definitions["MySQL host address"] = "MySQL ჰოსტის მისამსრთი";
$definitions["MySQL password"] = "MySQL პაროლი";
$definitions["MySQL queries"] = "MySQL შეკითხვები";
$definitions["MySQL table prefix"] = "MySQL ცხრილის პრეფიქსი";
$definitions["MySQL username"] = "MySQL მომხმარებელი";
$definitions["MySQL version"] = "MySQL ვერსია";

$definitions["Name"] = "სახელი";
$definitions["never"] = "არაზდროს";
$definitions["%s new"] = "%s ახალი";
$definitions["New conversation"] = "საუბარის დაწყება";
$definitions["New Conversation"] = "ახალი საუბარი";
$definitions["New conversations in the past week"] = "ახალი საუბრები გასულ კვირაში";
$definitions["New email"] = "ახალი ელ. ფოსტა";
$definitions["New members in the past week"] = "ახალი მომხმარებლები გასულ კვირაში";
$definitions["New password"] = "ახალი პაროლი";
$definitions["New posts in the past week"] = "ახალი გამოხმაურებები გასულ კვირაში";
$definitions["New username"] = "მომხმარებლის ახალი სახელი";
$definitions["Next Step"] = "შემდეგი ნაბიჯი";
$definitions["Next"] = "შემდეგ";
$definitions["No preview"] = "არ ჩანს";
$definitions["No"] = "არა";
$definitions["Notifications"] = "შეტყობინებები";
$definitions["Now"] = "ახლა";

$definitions["OK"] = "კარგი";
$definitions["Older"] = "ძველები";
$definitions["Online"] = "ხაზზეა";
$definitions["online"] = "ხაზზე";
$definitions["Only allow members of this group to see who else is in it"] = "მხოლოდ ამ ჯგუფის წევრებს მიეცით საშუალება ნახონ, ვინ არის მასში";
$definitions["Open registration"] = "გახსნილი რეგისტრაცია";
$definitions["optional"] = "სურვილისამებრ";
$definitions["Order By:"] = "მიხედვით მან:";
$definitions["Original Post"] = "პირველი გამოხმაურება";

$definitions["Page Not Found"] = "გვერდი არ არსებობს";
$definitions["Password"] = "პაროლი";
$definitions["PHP version"] = "PHP ვერსია";
$definitions["Plugins"] = "დანამატები";
$definitions["Post a Reply"] = "პასუხის დაწერა";
$definitions["Post count"] = "გამოხმაურების რაოდენობა";
$definitions["Posts"] = "პოსტები";
$definitions["Powered by"] = "ძრავი";
$definitions["Preview"] = "ნახვა";
$definitions["Previous"] = "უკან";
$definitions["Primary color"] = "ძირითადი ფერი";

$definitions["Quote"] = "ციტატირება";
$definitions["quote"] = "ციტატა";

$definitions["Read more"] = "წაიკითხეთ მეტი";
$definitions["Recent posts"] = "ბოლო გამოხმაურებები";
$definitions["Recover Password"] = "პაროლის აღდგენა";
$definitions["Registered members"] = "დარეგისტრირებული მომხმარებლები";
$definitions["Registration"] = "რეგისტრაცია";
$definitions["Registration Closed"] = "რეგისტრაცია შეჩერებულია";
$definitions["Remove avatar"] = "სურათის წაშლა";
$definitions["Rename Member"] = "მომხმარებლის გადარქმევა";
$definitions["Reply"] = "პასუხი";
$definitions["Report a bug"] = "შეცდომის შეტყობინება";
$definitions["Require administrator approval"] = "აუცილებელია ადმინისტრატორმა დამტკიცოს";
$definitions["Require users to confirm their email address"] = "აუცილებელია მომხმარებლის მისი ელ. ფოსტით დადასტურება";
$definitions["Restore"] = "აღადგინე";
$definitions["restore"] = "აღდგენა";
$definitions["Reset"] = "გადატვირთვა";

$definitions["Save Changes"] = "ცვლილების შენახვა";
$definitions["Save Draft"] = "შენახულებში დამახსოვრება";
$definitions["Search conversations..."] = "საუბრების ძებნა...";
$definitions["Search within this conversation..."] = "მოძებნეთ ამ საუბრის ფარგლებში...";
$definitions["Search"] = "ძებნა";
$definitions["See the private conversations I've had with %s"] = "პირადი საუბრები %s";
$definitions["Set a New Password"] = "დააყენეთ ახალი პაროლი";
$definitions["Settings"] = "პარამეტრები";
$definitions["Show an image in the header"] = "სურათის ჩვენება სათაურში";
$definitions["Show in context"] = "კონტექსტში ჩვენება";
$definitions["Show matching posts"] = "შესატყვისი გამოხმაურებების ჩვენება";
$definitions["Show the channel list by default"] = "განყოფილებების სიის ჩვენება ნაგულისხმევად";
$definitions["Show the conversation list by default"] = "აჩვენეთ საუბრის სია ნაგულისხმევად";
$definitions["Show the forum title in the header"] = "აჩვენე ფორუმის სახელწოდება სათაურში";
$definitions["Sign Up"] = "რეგისტრაცია";
$definitions["Skins"] = "გარეგნობები";
$definitions["Sort By"] = "დაწყობა";
$definitions["Specify Setup Information"] = "მიუთითეთ დაყენების ინფორმაცია";
$definitions["Star to receive notifications"] = "გამოწერა შეტყობინებების მისაღებად";
$definitions["Starred"] = "გამოიწერეთ";
$definitions["Start"] = "დაწყება";
$definitions["Start a conversation"] = "დაიწყეთ საუბარი";
$definitions["Start a new conversation"] = "დაიწყეთ ახალი საუბარი";
$definitions["Start a private conversation with %s"] = "დაიწყეთ პირადი საუბარი %s";
$definitions["Start Conversation"] = "საუბრის დაწყება";
$definitions["Starting a conversation"] = "დაიწყეთ საუბარი";
$definitions["Statistics"] = "სტატისტიკა";
$definitions["statistic.conversation.plural"] = "%s საუბრები";
$definitions["statistic.conversation"] = "%s საუბარი";
$definitions["statistic.member.plural"] = "%s მომხმარებლები";
$definitions["statistic.member"] = "%s მომხმარებელი";
$definitions["statistic.online.plural"] = "%s ამჟამად ხაზზეა";
$definitions["statistic.online"] = "%s ხაზზეა ამჟამად";
$definitions["statistic.post.plural"] = "%s გამოხმაურებები";
$definitions["statistic.post"] = "%s გამოხმაურება";
$definitions["Sticky"] = "მიმაგრება";
$definitions["Subscribe"] = "გამოწერა";
$definitions["Subscribed"] = "გამოწერილია";
$definitions["Subscription"] = "გამოწერები";
$definitions["Success!"] = "შესრულდა!";
$definitions["Suspend member"] = "მომხმარებლის შეჩერება";
$definitions["Suspend members."] = "მომხმარებლების შეჩერება.";
$definitions["Suspend"] = "შეჩერება";

$definitions["To get started with your forum, you might like to:"] = "თქვენი ფორუმის დასაწყებად, შეიძლება მოგეწონოთ:";

$definitions["Unapproved"] = "დაუმტკიცებელია";
$definitions["Unhide"] = "ჩვენება";
$definitions["Uninstall"] = "დეინსტალაცია";
$definitions["Unlock"] = "განბლოკვა";
$definitions["Unmute conversation"] = "მიმოწერის დადუმების მოხსნა";
$definitions["Unstarred"] = "არაა გამოწერილი";
$definitions["Unsticky"] = "ჩამოხსნა";
$definitions["Unsubscribe new users by default"] = "ნაგულისხმევად გააუქმეთ გამოწერა ახალ მომხმარებლებზე";
$definitions["Unsubscribe"] = "გამოწერის გაუქმება";
$definitions["Unsubscribed"] = "გამოწერა გაუქმებულია";
$definitions["Unsuspend member"] = "შეჩერების მოხსნა მომხმარებელზე";
$definitions["Unsuspend"] = "შეჩერების მოხსნა";
$definitions["Until someone replies"] = "სანამ ვინმე პასუხობს";
$definitions["Untitled conversation"] = "უსათაურო საუბარი";
$definitions["Upgrade esoTalk"] = "განაახლეთ ძრავა";
$definitions["Use a background image"] = "გამოიყენეთ გარეკანის ფოტო";
$definitions["Use for mobile"] = "გამოიყენეთ მობილურისთვის";
$definitions["Use friendly URLs"] = "გამოიყენეთ URL-ები";
$definitions["Used to verify your account and subscribe to conversations"] = "გამოიყენება თქვენი პროფილის დასადასტურებლად და საუბრების გამოსაწერად";
$definitions["Username"] = "მომხმარებელი";
$definitions["Username or Email"] = "მომხმარებელი ან ელ. ფოსტა";

$definitions["View %s's profile"] = "ნახვა %s'ს პროფილის";
$definitions["View all notifications"] = "ნახეთ ყველა შეტყობინება";
$definitions["View more"] = "ნახეთ შემდეგი";
$definitions["View your profile"] = "ნახეთ თქვენი პროფილი";
$definitions["View"] = "ნახვა";
$definitions["Viewing: %s"] = "დათვალიერება: %s";
$definitions["Viewing %s"] = "ნახვა %s";
$definitions["viewingPosts"] = "<b>%s-%s</b> ამის %s გამოხმაურებები";

$definitions["Warning"] = "გაფრთხილება";
$definitions["Welcome to esoTalk!"] = "მოგესალმებით ფორუმში!";
$definitions["We've logged you in and taken you straight to your forum's administration panel. You're welcome."] = "თქვენ შეხვედით სისტემაში და გადაგიყვანთ პირდაპირ თქვენი ფორუმის ადმინისტრაციულ პანელში. არაფრის.";
$definitions["Write a reply..."] = "დაწერეთ პასუხი...";

$definitions["Yes"] = "დიახ";
$definitions["You can manage channel-specific permissions on the channels page."] = "თქვენ შეგიძლიათ მართოთ განყოფილების სპეციფიკური ნებართვები განყოფილებების გვერძე.";
$definitions["Your current password"] = "თქვენი მიმდინარე პაროლი";


// Messages.
$definitions["message.404"] = "შეცდომა! - თქვენ მიერ მოთხოვნილი გვერდი ვერ მოიძებნა, სცადეთ დაბრუნდეთ და დააწკაპუნეთ სხვა ბმულზე.";
$definitions["message.accountNotYetApproved"] = "ადმინისტრატორს ჯერ არ დაუმტკიცებია თქვენი პროფილი, გთხოვთ მოითმინოთ!";
$definitions["message.ajaxDisconnected"] = "სერვერთან დაკავშირება შეუძლებელია. დაელოდე რამდენიმე წამს და <a href='javascript:jQuery.ETAjax.resumeAfterDisconnection()'>ისევ სცადეთ</a>, ან <a href='' onclick='window.location.reload();return false'>განაახლეთ გვერდი</a>.";
$definitions["message.ajaxRequestPending"] = "გამარჯობათ! ჩვენ ჯერ კიდევ ვამუშავებთ თქვენს ზოგიერთ მოთხოვნას! თუ ამ გვერდიდან გადახვალთ, შესაძლოა დაკარგოთ თქვენს მიერ განხორციელებული ბოლო ცვლილებები.";
$definitions["message.avatarError"] = "თქვენი ავატარის ატვირთვისას წარმოიშვა პრობლემა. დარწმუნდით, რომ იყენებთ გამოსახულების მოქმედ ტიპს (როგორც .jpg, .png, ან .gif) და ფაილი ნამდვილად არ არის დიდი.";
$definitions["message.cannotDeleteLastChannel"] = "გამარჯობათ, მოიცადეთ, ბოლო განყოფილებას ვერ წაშლით! სად წავიდოდა თქვენი საუბრები? ეს უბრალოდ სისულელეა.";
$definitions["message.cannotEditSinceReply"] = "თქვენ არ შეგიძლიათ თქვენი გამოხმაურების რედაქტირება, რადგან ვიღაცამ უპასუხა მას შემდეგ რაც თქვენ გამოაქვეყნეთ.";
$definitions["message.changesSaved"] = "თქვენი ცვლილებები შენახულია.";
$definitions["message.channelsHelp"] = "განყოფილებები გამოიყენება თქვენს ფორუმზე საუბრების კატეგორიზაციისთვის. თქვენ შეგიძლიათ შექმნათ იმდენი განყოფილება, რამდენიც საჭიროა, და გადააწყოთ/ჩამოტვირთოთ ისინი ქვემოთ გადმოსვლით.";
$definitions["message.channelSlugTaken"] = "ეს სიტყვები ბმულში უკვე გამოიყენება სხვა განყოფილების მიერ.";
$definitions["message.confirmDelete"] = "დარწმუნებული ხართ, რომ გსურთ ამის წაშლა? სერიოზულად, თქვენ ვერ შეძლებთ მის დაბრუნებას.";
$definitions["message.confirmDiscardPost"] = "თქვენ არ შეინახეთ თქვენი გამოხმაურება შენახულებში. გსურთ მისი გაუქმება?";
$definitions["message.confirmEmail"] = "სანამ დაიწყებთ თქვენი ახლად შექმნილი პროფილის გამოყენებას, თქვენ უნდა დაადასტუროთ თქვენი ელ. ფოსტის მისამართი. მომდევნო ერთი-ორი წუთის განმავლობაში თქვენ უნდა მიიღოთ ელ. ფოსტაზე წერილი ჩვენგან, რომელიც შეიცავს ბმულს თქვენი პროფილის გასააქტიურებლად.";
$definitions["message.confirmLeave"] = "უი, თქვენ არ შეინახეთ მასალა, რომელსაც არედაქტირებთ! თუ ამ გვერდის დატოვებთ, თქვენ დაკარგავთ თქვენს მიერ განხორციელებულ ყველა ცვლილებას. ეს კარგია?";
$definitions["message.connectionError"] = "ფორუმის ძრავა ვერ დაუკავშირდა MySQL სერვერს. დაბრუნებული შეცდომა იყო:<br/>%s";
$definitions["message.conversationDeleted"] = "საუბარი წაიშალა. კარგი არ იყო?";
$definitions["message.conversationNotFound"] = "რატომღაც ამ საუბრის ნახვა შეუძლებელია. ის შეიძლება არ არსებობდეს, ან შეიძლება არ გქონდეთ მისი ნახვის უფლება.";
$definitions["message.cookieAuthenticationTheft"] = "უსაფრთხოების მიზეზების გამო, ჩვენ არ შეგვეძლო შესვლა თქვენი „დამახსოვრების“ ქუქიით. გთხოვთ შეხვიდეთ ხელით!";
$definitions["message.deleteChannelHelp"] = "თუ ამ განყოფილებას წაშლით, მისი დაბრუნების გზა აღარ იქნება. არ იქნება მისი დაბრუნების <em>იოლი</em> გზა. ამ განყოფილების ყველა მიმოწერა შეიძლება გადაიტანოთ თქვენს მიერ არჩეულ სხვაზე.";
$definitions["message.emailConfirmed"] = "თქვენი პროფილი დამოწმებულია და ახლა შეგიძლიათ დაიწყოთ საუბრებში მონაწილეობა. რატომ არ <a href='".URL("conversation/start")."'>დაიწყებთ ერთს</a> თქვენ თვითონ?";
$definitions["message.emailDoesntExist"] = "ელ. ფოსტის ეს მისამართი არ ემთხვევა მონაცემთა ბაზის არცერთ წევრს. შეცდომა დაუშვი?";
$definitions["message.emailNotYetConfirmed"] = "თქვენ უნდა დაადასტუროთ თქვენი ელ. ფოსტა, სანამ შეძლებთ მასში შესვლას! თუ არ მიგიღიათ დამადასტურებელი ელ. ფოსტის წერილი, გთხოვთ, შეამოწმოთ თქვენი სპამის საქაღალდე ან <a href='%s'>დააწკაპუნეთ აქ ხელახლა გასაგზავნად</a>.";
$definitions["message.emailTaken"] = "ამ ელ. ფოსტის წევრი უკვე არის!";
$definitions["message.empty"] = "თქვენ უნდა შეავსოთ ეს ველი.";
$definitions["message.emptyPost"] = "გამოხმაურება ცარიელია.";
$definitions["message.emptyTitle"] = "თქვენი საუბრის სათაური არ შეიძლება იყოს ცარიელი.";
$definitions["message.esoTalkAlreadyInstalled"] = "<strong>ფორუმის ძრავა უკვე დაინსტალირდა.</strong> ფორუმის ძრავის ხელახლა ინსტალაციისთვის უნდა წაშალოთ <code>config/config.php</code>.";
$definitions["message.esoTalkUpdateAvailable"] = "ძრავის ახალი ვერსია, %s, უკვე ხელმისაწვდომია.";
$definitions["message.esoTalkUpdateAvailableHelp"] = "უსაფრთხოების რისკის შესამცირებლად რეკომენდირებულია ყოველთვის დააინსტალიროთ ფორუმის ძრავის უახლესი ვერსია. შეიძლება იყოს რამდენიმე მაგარი ახალი ფუნქცია!";
$definitions["message.esoTalkUpToDate"] = "ფორუმის ძრავის თქვენი ვერსია განახლებულია.";
$definitions["message.esoTalkUpToDateHelp"] = "ძრავისთვის <a href='%s' target='_blank'>მადლობის გადახდა</a>";
$definitions["message.fatalError"] = "ფორუმის ძრავას შეექმნა ფატალური შეცდომა. სცადეთ ხელახლა, ან <a href='%1\$s' target='_blank'>მიიღეთ დახმარება</a>.";
$definitions["message.fileUploadFailed"] = "მოხდა რაღაც შეცდომა და თქვენ მიერ არჩეული ფაილის ატვირთვა ვერ მოხერხდა. იქნებ ძალიან დიდია, ან არასწორ ფორმატში?";
$definitions["message.fileUploadFailedMove"] = "თქვენ მიერ ატვირთული ფაილის დანიშნულების ადგილზე კოპირება ვერ მოხერხდა. გთხოვთ დაუკავშირდეთ ფორუმის ადმინისტრატორს.";
$definitions["message.fileUploadNotImage"] = "თქვენ მიერ ატვირთული ფაილი არ არის გამოსახულება მისაღები ფორმატით.";
$definitions["message.fileUploadTooBig"] = "თქვენ მიერ არჩეული ფაილის ატვირთვა ვერ მოხერხდა, რადგან ის ძალიან დიდია.";
$definitions["message.forgotPasswordHelp"] = "დაგავიწყდათ პაროლი? არ ინერვიულო, ეს ყოველთვის ხდება. უბრალოდ შეიყვანეთ თქვენი ელ. ფოსტის მისამართი და ჩვენ გამოგიგზავნით ინსტრუქციებს, თუ როგორ დააყენოთ ახალი.";
$definitions["message.fulltextKeywordWarning"] = "გაითვალისწინეთ, რომ 4 სიმბოლოზე ნაკლები სიგრძის საკვანძო სიტყვები და საერთო ინგლისური სიტყვები, როგორიცაა „the“ და „for“, არ შედის საძიებო კრიტერიუმებში.";
$definitions["message.gambitsHelp"] = "გამბიტები არის ფრაზები, რომლებიც აღწერს იმას, რასაც ეძებთ. დააწკაპუნეთ გამბიტზე, რომ ჩასვათ იგი საძიებო ველში. ორჯერ დააწკაპუნეთ გამბიტზე, რომ მყისიერად მოძებნოთ იგი. ნორმალური საძიებო საკვანძო სიტყვებიც მუშაობს!";
$definitions["message.gdNotEnabledWarning"] = "<strong>GD გაფართოება არ არის ჩართული.</strong> ეს საჭიროა ავატარების ზომის შესაცვლელად და შესანახად. სთხოვეთ თქვენს მასპინძელს ან ადმინისტრატორს დააინსტალიროთ/ჩართოთ იგი.";
$definitions["message.greaterMySQLVersionRequired"] = "<strong>თქვენ უნდა გქონდეთ დაინსტალირებული MySQL 4 ან მეტი და <a href='http://php.net/manual/en/mysql.installation.php' target='_blank'>MySQL გაფართოება ჩართულია PHP-ში</a>.</strong> გთხოვთ, დააინსტალიროთ/განაახლეთ ორივე ეს მოთხოვნა ან მოითხოვეთ, რომ თქვენმა ჰოსტმა ან ადმინისტრატორმა დააინსტალიროს ისინი.";
$definitions["message.greaterPHPVersionRequired"] = "<strong>თქვენს სერვერს უნდა ჰქონდეს PHP %s ან მეტი დაინსტალირებული ფორუმის ძრავის გასაშვებად</strong> გთხოვთ, განაახლოთ თქვენი PHP ინსტალაცია ან მოითხოვოთ, რომ თქვენს ჰოსტს ან ადმინისტრატორს განაახლოს სერვერი.";
$definitions["message.groupsHelp"] = "ჯგუფები გამოიყენება თქვენს ფორუმზე წევრების კატეგორიზაციისთვის. თქვენ შეგიძლიათ შექმნათ იმდენი ჯგუფი, რამდენიც საჭიროა.";
$definitions["message.incorrectLogin"] = "თქვენი შესვლის დეტალები არასწორი იყო.";
$definitions["message.incorrectPassword"] = "თქვენი მიმდინარე პაროლი არასწორია.";
$definitions["message.installerAdminHelp"] = "ფორუმის ძრავის გამოიყენებს შემდეგ თქვენი ადმინისტრატორის პროფილის დასაყენებლად თქვენს ფორუმზე.";
$definitions["message.installerFilesNotWritable"] = "<strong>ფორუმის ძრავა ვერ წერს შემდეგ ფაილებს/საქაღალდეებს: %s.</strong> ამის გადასაჭრელად, თქვენ უნდა გადახვიდეთ ამ ფაილებში/საქაღალდეებში თქვენს FTP კლიენტში და <code>chmod</code> მათ <code>0777</code>.";
$definitions["message.installerWelcome"] = "შექმენით თქვენი ფორუმი, მაგრამ შეავსეთ ქვემოთ მოცემული ფორმა.<br>თუ რაიმე პრობლემა გაქვთ, მიიღეთ დახმარება <a href='%s' target='_blank'>ფორუმის ძრავის საიტზე</a>.";
$definitions["message.invalidChannel"] = "თქვენ აირჩიეთ არასწორი განყოფილება!";
$definitions["message.invalidEmail"] = "როგორც ჩანს, ეს ელ. ფოსტის მისამართი არასწორია...";
$definitions["message.invalidUsername"] = "თქვენ უნდა აირჩიოთ მომხმარებლის სახელი 3-დან 20-მდე ალფაციფრულ სიმბოლოს შორის.";
$definitions["message.javascriptRequired"] = "ამ გვერდის გამართულად ფუნქციონირებისთვის საჭიროა JavaScript. გთხოვთ ჩართოთ!";
$definitions["message.languageUninstalled"] = "ენა წაიშალა.";
$definitions["message.locked"] = "როგორც ჩანს, ეს საუბარი <strong>დახურულია</strong>, ასე რომ თქვენ ვერ უპასუხებთ მას.";
$definitions["message.loginToParticipate"] = "საუბრის დასაწყებად ან გამოხმაურებებზე პასუხის გასაცემად გთხოვთ გაიაროთ ავტორიზაცია.";
$definitions["message.logInToReply"] = "<a href='%1\$s' class='link-login'>ავტორიზაცია</a> ან <a href='%2\$s' class='link-join'>რეგისტრაცია</a> პასუხის დასაწერად!";
$definitions["message.logInToSeeAllConversations"] = "<a href='".URL("user/login")."' class='link-login'>ავტორიზაცია</a> ზოგიერთი განყოფილების/საუბრის სანახავად, რომელიც შესაძლოა დამალული იყოს სტუმრებისთვის.";
$definitions["message.memberNotFound"] = "წევრი არ მოიძებნა.";
$definitions["message.memberNoPermissionView"] = "ამ წევრის დამატება შეუძლებელია, რადგან მას არ აქვს განყოფილების ნახვის უფლება, რომელშიც ეს საუბარია.";
$definitions["message.nameTaken"] = "მომხმარებლის სახელი დაკავებულია ან არის დაცული სიტყვა.";
$definitions["message.newSearchResults"] = "იყო ახალი აქტივობა, რომელმაც გავლენა მოახდინა თქვენი ძიების შედეგებზე. <a href='%s'>განახლება</a>";
$definitions["message.noActivity"] = "%s ჯერ არაფერი გამიკეთებია ამ ფორუმზე!";
$definitions["message.noChannels"] = "განყოფილებები არ ჩანს.";
$definitions["message.noMembersOnline"] = "ამჟამად არცერთი წევრი არ არის ხაზზე.";
$definitions["message.noNotifications"] = "თქვენ არ გაქვთ შეტყობინებები.";
$definitions["message.noPermission"] = "თქვენ არ გაქვთ ამ მოქმედების შესრულების ნებართვა.";
$definitions["message.noPermissionToReplyInChannel"] = "თქვენ არ გაქვთ ამ განყოფილების საუბრებზე პასუხის უფლება.";
$definitions["message.noPluginsInstalled"] = "ამჟამად არ არის დაინსტალირებული დანამატები.";
$definitions["message.noSearchResults"] = "არ მოიძებნა თქვენი ძიების შესაბამისი მიმოწერა.";
$definitions["message.noSearchResultsMembers"] = "არ მოიძებნა თქვენი ძიების შესაბამისი მომხმარებელები.";
$definitions["message.noSearchResultsPosts"] = "არ მოიძებნა თქვენი ძიების შესაბამისი გამოხმაურებები.";
$definitions["message.noSkinsInstalled"] = "ამჟამად გარეგნობა არ არის დაინსტალირებული.";
$definitions["message.notWritable"] = "<code>%s</code> არ არის ჩაწერადი. სცადეთ <code>chmod</code>შეიტანეთ იგი <code>777</code>, ან თუ არ არსებობს, <code>chmod</code> საქაღალდე, რომელიც შეიცავს.";
$definitions["message.pageNotFound"] = "გვერდი, რომელსაც ეძებთ, ვერ მოიძებნა.";
$definitions["message.passwordChanged"] = "თქვენი პაროლი შეიცვალა. ახლა შეგიძლიათ შეხვიდეთ!";
$definitions["message.passwordEmailSent"] = "ჩვენ გამოგიგზავნეთ ელ. ფოსტა, რომელიც შეიცავს ბმულს თქვენი პაროლის აღდგენისთვის. შეამოწმეთ თქვენი სპამის საქაღალდე, თუ არ მიიღებთ მას მომდევნო ან ორ წუთში.";
$definitions["message.passwordsDontMatch"] = "თქვენი პაროლები არ ემთხვევა.";
$definitions["message.passwordTooShort"] = "თქვენი პაროლი ძალიან მოკლეა.";
$definitions["message.pluginCannotBeEnabled"] = "დანამატი <em>%s</em> არ შეიძლება ჩართოთ: %s";
$definitions["message.pluginDependencyNotMet"] = "ამ მოდულის ჩასართავად უნდა გქონდეთ დაინსტალირებული და ჩართული %s ვერსია %s.";
$definitions["message.pluginUninstalled"] = "დანამატის დეინსტალაცია განხორციელდა.";
$definitions["message.postNotFound"] = "გამოხმაურება, რომელსაც ეძებთ, ვერ მოიძებნა.";
$definitions["message.postTooLong"] = "სიმბოლოების მაქსიმალური რაოდენობაა %s.";
$definitions["message.preInstallErrors"] = "ეს შეცდომები უნდა მოგვარდეს ინსტალაციის გაგრძელებამდე.";
$definitions["message.preInstallWarnings"] = "შეგიძლიათ გააგრძელოთ ფორუმის ძრავის ინსტალაცია შემდეგი გაფრთხილებების გადაჭრის გარეშე, მაგრამ ფორუმის ძრავის ზოგიერთი ფუნქცია შეიძლება შეზღუდული იყოს.";
$definitions["message.reduceNumberOfGambits"] = "შეამცირეთ გამბიტების ან საძიებო საკვანძო სიტყვების რაოდენობა, რომლებსაც იყენებთ საუბრების უფრო ფართო დიაპაზონის მოსაძებნად.";
$definitions["message.registerGlobalsWarning"] = "<strong>PHP register_globals პარამეტრი ჩართულია.</strong> მიუხედავად იმისა, რომ ფორუმის ძრავა შეიძლება იმუშაოს ამ პარამეტრით, რეკომენდებულია მისი გამორთვა უსაფრთხოების გაზრდისა და ფორუმის ძრავის პრობლემების თავიდან ასაცილებლად.";
$definitions["message.registrationClosed"] = "ამ ფორუმზე რეგისტრაცია არ არის ღია.";
$definitions["message.removeDirectoryWarning"] = "Hროგორც ჩანს, თქვენ არ წაშალეთ <code>%s</code> დირექტორია, როგორც ჩვენ გითხარით! თქვენ ალბათ უნდა გააკეთოთ, მხოლოდ იმისთვის, რომ დარწმუნდეთ, რომ ეს ჰაკერები ვერაფერს გააკეთებენ ბოროტებას.";
$definitions["message.safeModeWarning"] = "<strong>Safe mode ჩართულია.</strong> მისმა შეიძლება პოტენციურად გამოიწვიოს პრობლემები ფორუმის ძრავასთან, მაგრამ თქვენ მაინც შეგიძლიათ გააგრძელოთ, თუ ვერ გამორთეთ.";
$definitions["message.searchAllConversations"] = "სცადეთ ამ ტერმინის მოძიება ყველა მიმოწერაში.";
$definitions["message.setNewPassword"] = "როგორი გსურთ იყოს თქვენი ახალი პაროლი?";
$definitions["message.skinUninstalled"] = "გარეგნობა დეინსტალირებულია.";
$definitions["message.suspended"] = "ფორუმის მოდერატორმა <strong>შეაჩერა</strong> თქვენი პროფილი";
$definitions["message.suspendMemberHelp"] = " %s შეჩერება ხელს შეუშლის მათ საუბრებზე პასუხის გაცემას, საუბრების დაწყებას და პირადი საუბრების ნახვას. მათ ექნებათ იგივე ნებართვები, როგორც სტუმარებს.";
$definitions["message.tablePrefixConflict"] = "ინსტალერმა აღმოაჩინა, რომ არის ფორუმის ძრავის კიდევ ერთი ინსტალაცია იმავე MySQL მონაცემთა ბაზაში იმავე ცხრილის პრეფიქსით.<br>• ამ ინსტალაციის გადასაწერად კვლავ დააწკაპუნეთ „ინსტალაციაზე“. <strong>ყველა მონაცემი დაიკარგება.</strong><br>• ამ ინსტალაციის გვერდით ახალი ინსტალაციის შესაქმნელად შეცვალეთ ცხრილის პრეფიქსი.";
$definitions["message.unsuspendMemberHelp"] = " %s შეჩერების გაუქმება მას საშუალებას მისცემს კვლავ მიიღოს მონაწილეობა ამ ფორუმზე საუბრებში.";
$definitions["message.upgradeSuccessful"] = "ფორუმის ძრავა წარმატებით განახლდა.";
$definitions["message.waitForApproval"] = "სანამ დაიწყებთ თქვენი ახლად შექმნილი პროფილის გამოყენებას, ადმინისტრატორმა უნდა დაამტკიცოს თქვენი პროფილი. ჩვენ გამოგიგზავნით ელ. ფოსტას, როცა დამტკიცდებით!";
$definitions["message.waitToReply"] = "თქვენ უნდა დაელოდოთ მინიმუმ %s წამი მიმოწერის დაწყებას ან პასუხს შორის დრის ხანგრძლივობას.";
$definitions["message.waitToSearch"] = "როგორც ჩანს, თქვენ ცდილობთ განახორციელოთ ძალიან ბევრი ძიება. დაელოდეთ %s წამს და სცადეთ ხელახლა.";


// Emails.
$definitions["email.header"] = "<p>მოგესალმებით %s!</p>";
$definitions["email.footer"] = "<p>(თუ აღარ გსურთ მსგავსი ელ. ფოსტის მიღება, შეგიძლიათ <a href='%s'> შეცვალოთ თქვენი შეტყობინებების პარამეტრები</a>.)</p>";

$definitions["email.confirmEmail.subject"] = "%1\$s, გთხოვთ დაადასტუროთ თქვენი ელ. ფოსტა";
$definitions["email.confirmEmail.body"] = "<p>ვიღაც (იმედია თქვენ!) დარეგისტრირდა ფორუმზე '%1\$s' ამ ელფოსტის მისამართით.</p><p>თუ ეს თქვენ იყავით, უბრალოდ ეწვიეთ შემდეგ ბმულს და თქვენი ანგარიში გააქტიურდება:<br>%2\$s</p>";

$definitions["email.approved.subject"] = "%1\$s, თქვენი პროფილი დამტკიცებულია";
$definitions["email.approved.body"] = "<p>თქვენი პროფილი %1\$s ზე დამტკიცდა.</p><p>შესვლისთვის ეწვიეთ შემდეგ ბმულს და დაიწყოთ საუბარი:<br>%2\$s</p>";

$definitions["email.forgotPassword.subject"] = "დაგავიწყდათ პაროლი?, %1\$s?";
$definitions["email.forgotPassword.body"] = "<p>ვიღაცამ (იმედია თქვენ!) წარადგინა თქვენი პროფილის დავიწყებული პაროლის მოთხოვნა ფორუმზე '%1\$s'. თუ არ გსურთ პაროლის შეცვლა, უბრალოდ დააიგნორეთ ეს ელ. ფოსტა და არაფერი მოხდება.</p><p>თუმცა, თუ დაგავიწყდათ პაროლი და გსურთ ახლის დაყენება, ეწვიეთ შემდეგ ბმულს:<br>%2\$s</p>";

$definitions["email.mention.subject"] = "[ნახსენები %1\$s] %2\$s";
$definitions["email.mention.body"] = "<p><strong>%1\$s</strong> საუბარში ერთ გამოხმაურებაში მოგახსენეთ <strong>%2\$s</strong>.</p><hr>%3\$s<hr><p>გამოხმაურების კონტექსტში სანახავად გადადით შემდეგ ბმულზე:<br>%4\$s</p>";

$definitions["email.privateAdd.subject"] = "[პირადი] %1\$s";
$definitions["email.privateAdd.body"] = "<p>თქვენ დამატებული ხართ პირად საუბარში სათაურით <strong>%1\$s</strong>.</p><hr>%2\$s<hr><p>ამ საუბრის სანახავად გადადით შემდეგ ბმულზე:<br>%3\$s</p>";

$definitions["email.post.subject"] = "[ახალი პასუხი] %1\$s";
$definitions["email.post.body"] = "<p><strong>%1\$s</strong> უპასუხა საუბარს, რომელიც თქვენ გამოიწერეთ: <strong>%2\$s</strong></p><hr>%3\$s<hr><p>ახალი აქტივობის სანახავად გადადით შემდეგ ბმულზე:<br>%4\$s</p>";


// Translating the gambit system can be quite complex, but we'll do our best to get you through it. :)
// Note: Don't use any html entities in these definitions, except for: &lt; &gt; &amp; &#39;

// Simple gambits
// These gambits are pretty much evaluated as-they-are.
// tag:, author:, contributor:, and quoted: are combined with a value after the colon (:).
// For example: tag:video games, author:myself
$definitions["gambit.author:"] = "ავტორი:";
$definitions["gambit.contributor:"] = "კონტრიბუტორი:";
$definitions["gambit.member"] = "მომხმარებელი";
$definitions["gambit.myself"] = "თქვენი";
$definitions["gambit.draft"] = "შენახული";
$definitions["gambit.locked"] = "დახურული";
$definitions["gambit.order by newest"] = "ახლების მიხედვით";
$definitions["gambit.order by replies"] = "პასუხების მიხედვით";
$definitions["gambit.private"] = "პირადული";
$definitions["gambit.random"] = "შემთხვევითი";
$definitions["gambit.reverse"] = "საპირისპირო";
$definitions["gambit.starred"] = "გამოწერილი";
$definitions["gambit.ignored"] = "იგნორირებული";
$definitions["gambit.sticky"] = "მიმაგრებული";
$definitions["gambit.unread"] = "წაუკითხავი";
$definitions["gambit.limit:"] = "შეზღუდვა:";
$definitions["gambit.title:"] = "სათაური:";

// Aliases
// These are gambits which tell the gambit system to use another gambit.
// In other words, when you type "active today", the gambit system interprets it as if you typed "active 1 day".
// The first of each pair, the alias, can be anything you want.
// The second, however, must fit with the regular expression pattern defined below (more on that later.)
$definitions["gambit.active today"] = "აქტიური დღეს"; // what appears in the gambit cloud
$definitions["gambit.active 1 day"] = "აქტიური 1 დღე"; // what it actually evaluates to

$definitions["gambit.has replies"] = "აქვს პასუხები";
$definitions["gambit.has >0 replies"] = "აქვს >0 პასუხები";
$definitions["gambit.has >10 replies"] = "აქვს >10 პასუხი";

$definitions["gambit.has no replies"] = "არ აქვს პასუხები";
$definitions["gambit.has 0 replies"] = "აქვს 0 პასუხი";

$definitions["gambit.dead"] = "მკვდარი გამბიტი";
$definitions["gambit.active >30 day"] = "აქტიური >30 დღე";

// Units of time
// These are used in the active gambit.
// ex. "[active] [>|<|>=|<=|last] 180 [second|minute|hour|day|week|month|year]"
$definitions["gambit.second"] = "წამი";
$definitions["gambit.minute"] = "წუთი";
$definitions["gambit.hour"] = "საათი";
$definitions["gambit.day"] = "დღე";
$definitions["gambit.week"] = "კვირა";
$definitions["gambit.month"] = "თვე";
$definitions["gambit.year"] = "წელი";
$definitions["gambit.last"] = "ბოლო"; // as in "active last 180 days"
$definitions["gambit.active"] = "აქტიური"; // as in "active last 180 days"

// Now the hard bit. This is a regular expression to test for the "active" gambit.
// The group (?<a> ... ) is the comparison operator (>, <, >=, <=, or last).
// The group (?<b> ... ) is the number (ex. 24).
// The group (?<c> ... ) is the unit of time.
// The languages of "last" and the units of time are defined above.
// However, if you need to reorder the groups, do so carefully, and make sure spaces are written as " *".
$definitions["gambit.gambitActive"] = "/^{$definitions["gambit.active"]} *(?<a>>|<|>=|<=|{$definitions["gambit.last"]})? *(?<b>\d+) *(?<c>{$definitions["gambit.second"]}|{$definitions["gambit.minute"]}|{$definitions["gambit.hour"]}|{$definitions["gambit.day"]}|{$definitions["gambit.week"]}|{$definitions["gambit.month"]}|{$definitions["gambit.year"]})/";

// These appear in the tag cloud. They must fit the regular expression pattern where the ? is a number.
// If the regular expression pattern has been reordered, these gambits must also be reordered (as well as the ones in aliases.)
$definitions["gambit.active last ? hours"] = "{$definitions["gambit.active"]} {$definitions["gambit.last"]} ? {$definitions["gambit.hour"]}";
$definitions["gambit.active last ? days"] = "{$definitions["gambit.active"]} {$definitions["gambit.last"]} ? {$definitions["gambit.day"]}";

// This is similar to the regular expression for the active gambit, but for the "has n reply(s)" gambit.
// Usually you just need to change the "has" and "repl".
$definitions["gambit.gambitHasNReplies"] = "/^has *(?<a>>|<|>=|<=)? *(?<b>\d+) *repl/";
