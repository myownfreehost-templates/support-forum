<?php
// Copyright 2023 Merab Mazmanian
// This file is part of esoTalk. Please see the included license file for usage information.

// Georgian Definitions for the Debug plugin.

$definitions["MySQL queries"] = "MySQL მოთხოვნები";
$definitions["Page loaded in %s seconds"] = "გვერდი ჩაიტვირთა %s წამში";
$definitions["POST + GET + FILES information"] = "POST + GET + FILES ინფორმაცია";
$definitions["SESSION + COOKIE information"] = "SESSION + COOKIE ინფორმაციაn";
