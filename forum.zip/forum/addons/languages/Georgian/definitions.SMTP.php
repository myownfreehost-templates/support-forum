<?php
// Copyright 2023 Merab Mazmanian
// This file is part of esoTalk. Please see the included license file for usage information.

// Georgian Definitions for the SMTP plugin.

$definitions["Server"] = "სერვერი";
$definitions["Port"] = "პორტი";
$definitions["Authentication"] = "ავთენტიფიკაცია";
$definitions["Normal"] = "ნორმალური";
$definitions["TLS"] = "TLS";
$definitions["SSL"] = "SSL";
