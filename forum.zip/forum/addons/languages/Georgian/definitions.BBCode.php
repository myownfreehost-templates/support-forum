<?php
// Copyright 2023 Merab Mazmanian
// This file is part of esoTalk. Please see the included license file for usage information.

// Georgian Definitions for the BBCode plugin.

$definitions["Code"] = "კოდი";
$definitions["Image"] = "სურათი";
$definitions["Link"] = "ბმული";
$definitions["Strike"] = "გადახაზული";
$definitions["Header"] = "სათაური";
$definitions["Italic"] = "დახრილი";
$definitions["Bold"] = "მსხვილი";
